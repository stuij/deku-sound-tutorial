#ifndef DATA_H
#define DATA_H

#include "Gba.h"

	// in Data.c
extern const u16 dPalSys[16];
extern const u16 dFontBg[];
extern const u16 dFontMapBg[];

	// in SndData.S
extern const s8 dSndPiano[];

#endif
